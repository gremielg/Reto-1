import UIKit

for i in 0...100{
    var a = 0 //variable divisible entre 5
    var b = 0 //variable divisible entre 2
    let c = 5 //constante para dividir entre 5
    let d = 2 //constante para dividir entre 2
    a = i % c // Calculo para determinar si es multiplo de 5 partiendo del residuo de la division
    b = i % d // Calculo para determinar si es par partiendo del residuo de la division
    switch i {
    case 30...40: // lee los numeros del 30 al 40
        if (a == 0) && (b == 0){ // verifica si es par y multiplo de 5 cada numero del grupo
            print("#", i, "Par", "Bingo", "Viva Swift")
        }else if (a == 0){ // verifica si es multiplo de 5 y si son Impares
            print("#", i ,"Impar", "Bingo", "Viva Swift")
        }else if (b == 0){ // verifica si es par
            print("#", i , "Par" , "Viva Swift")
        }else{ // accesara los impares
            print("#", i , "Impar", "Viva Swift")
        }
    
        
    default: //accesara los demas numeros menores a 30 y mayores de 40 del grupo de 1 al 100
        if (a == 0) && (b == 0){
            print("#", i, "Par", "Bingo")
        }else if (a == 0){
            print("#", i ,"Impar", "Bingo")
        }else if (b == 0){
            print("#", i , "Par")
        }else{
            print("#", i , "Impar")
        }
        }
        
    }
